<template>
    <div class="empty">
        <img src="./img/conEmpty.png" alt="">
        <p>暂无内容~</p>
    </div>
</template>
<script>
export default {
  name: 'xyzConEmpty'
}
</script>
<style lang="sass" scoped>
@import './css/empty.scss';
</style>

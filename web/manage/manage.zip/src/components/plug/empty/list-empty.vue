<template>
    <div class="empty">
        <img src="./img/listEmpty.png" alt="">
        <p>暂无内容~</p>
    </div>
</template>
<script>
export default {
  name: 'xyzListEmpty'
}
</script>
<style lang="sass" scoped>
    @import './css/empty.scss';
</style>

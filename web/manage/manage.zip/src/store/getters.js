const getters = {
  token: state => state.user.token,
  cachedViews: state => state.app.cachedViews
}
export default getters

# mobile-vant

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn serve
```

### Compiles and minifies for production
```
yarn build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


# 使用前，建议先了解src/components/plug下所有的组件，优先使用已有的全局组件
### 推荐layout（框架布局）和VanFieldCheckbox（多选）、VanFieldSelectPicker（单选）
### 文档地址：
https://docs.qq.com/doc/DQ0htR1lpTXhqU3Zs